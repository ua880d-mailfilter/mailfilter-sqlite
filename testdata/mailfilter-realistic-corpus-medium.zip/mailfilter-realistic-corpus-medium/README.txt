mailfilter realistic medium corpus
================================

Inhalt
------
Synthetisch erzeugtes, aber realistisch gemischtes Test-Corpus für Mailfilter_Sqlite.

Umfang
------
Spam: 1050
Ham : 450
Gesamt: 1500

Verzeichnisstruktur
-------------------
spam/
  phishing_paypal/
  phishing_amazon/
  promo_bulk/
  fake_brands/
  account_bait/

ham/
  shops/
  platforms/
  newsletters/
  personal/
  security/

Ziele des Corpus
----------------
- conservative vs aggressive Export prüfen
- Fake-Brand Detection prüfen
- Campaign-/Domain-/Host-Logik unter Last prüfen
- ALLOW proximity und protected domains gegen legitime Mails prüfen
- time_risk mit realistischen Datumsfenstern prüfen
